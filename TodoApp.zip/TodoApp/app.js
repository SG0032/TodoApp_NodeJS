const express = require('express');
const mongoose = require('mongoose');
const bodyParser = require('body-parser');
const methodOverride = require('method-override');

mongoose.connect('mongodb+srv://admin:admin2021@todoappcluster.nduzu.mongodb.net/myFirstDatabase?retryWrites=true&w=majority').then(()=>{
    console.log('Connected to DataBase');
});

const app = express();

app.use(bodyParser.urlencoded({extended : false}));

app.use(methodOverride('_method'));

app.set('view engine', 'pug');

const indexRoutes = require('./routes/index');
app.use('/', indexRoutes);

const port = 3000;
app.listen(port, () => console.log('Serveur lance sur le port ${port}.'));